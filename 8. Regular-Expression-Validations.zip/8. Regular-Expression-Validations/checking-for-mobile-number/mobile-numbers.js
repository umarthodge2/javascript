function allnumeric(inputtxt)
{
	//{10} only 10
	//{10,12} min 10, max 12
	var numbers = /^[0-9]{10,12}$/;
	if(inputtxt.value.match(numbers))
	{
		alert('Mobile number accepted....');
		document.form1.text1.focus();
		return true;
	}
	else
	{
		alert('Please enter valid mobile number');
		document.form1.text1.focus();
		return false;
	}
}